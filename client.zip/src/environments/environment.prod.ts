export const environment = {
  production: true,
  apiUrl: 'https://api-climonllor.herokuapp.com',
};
