export enum validRoles {
  Administrador = 1,
  Profesional,
  Paciente,
}

export enum validDays {
  Lunes = 1,
  Martes,
  Miercoles,
  Jueves,
  Viernes,
  Sabado,
  Domingo
}
