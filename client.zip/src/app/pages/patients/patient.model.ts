import { User } from '../admin/users/user.model';
export class Patient extends User {
}
